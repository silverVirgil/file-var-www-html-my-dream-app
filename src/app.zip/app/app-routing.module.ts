import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EtudiantsComponent } from './etudiants/etudiants.component';
import { AccueilComponent } from './accueil/accueil.component';


const routes: Routes = [
  {path:'etudiants', component:EtudiantsComponent},
  {path:'', component:AccueilComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
